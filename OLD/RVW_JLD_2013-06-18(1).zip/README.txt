Thank you for reading!  I hope you enjoy watching this routine as much as I enjoyed writing it!
Instructions:
1  Unzip RVW_JLD_[date].zip
2  Open RVW_challenge.c in ROBOTC
3  Set compiler target to Virtual Worlds
4  Compile and Download
5  Log in to Virtual Worlds as a guest
6  Click 'Single Player'
7  Use the following settings:
	Robot -		VEX IntakeBot
	Game Mode -	CS2N Competition
	Start Point -	Red | Hanging Zone
8  Click 'Start' and then >
9  Enjoy